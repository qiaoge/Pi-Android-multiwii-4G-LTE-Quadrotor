void applog(const char *format, ...);
void applog_flush();
