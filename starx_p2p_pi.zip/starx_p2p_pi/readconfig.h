int GetProfileString(FILE *fp, char *AppName, char *KeyName, char *KeyVal );
